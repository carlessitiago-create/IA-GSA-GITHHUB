import React, { useState, useEffect } from 'react';
import { Activity, CheckCircle, Clock, Search, Filter, ChevronRight, User, Calendar, FileText, AlertCircle, X, ExternalLink, ShieldCheck, UserCheck, FileDown, Loader2, FolderOpen, AlertTriangle, XCircle, Trash2, Edit3 } from 'lucide-react';
import { format } from 'date-fns';
import { listarTodosProcessos, OrderProcess, atualizarStatusProcesso, abrirPendenciaCascata, excluirProcesso } from '../../services/orderService';
import { auth } from '../../firebase';
import { motion, AnimatePresence } from 'motion/react';
import { gerarDocumentoProcesso } from '../../services/pdfGeneratorService';
import { getClienteData } from '../../services/leadService';
import { obterModeloProcesso } from '../../services/modelService';
import { SmartFicha } from './SmartFicha';
import Swal from 'sweetalert2';
import { useAuth } from '../../components/AuthContext';
import { useRequirements } from '../../hooks/useRequirements';

export const OperationalView: React.FC = () => {
  const { profile } = useAuth();
  const isAdm = profile?.nivel?.startsWith('ADM') || profile?.nivel === 'ADM_ANALISTA';
  const { config: requirementsConfig } = useRequirements();
  const [processos, setProcessos] = useState<OrderProcess[]>([]);
  const [loading, setLoading] = useState(true);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedProcess, setSelectedProcess] = useState<OrderProcess | null>(null);
  const [selectedClient, setSelectedClient] = useState<any>(null);

  useEffect(() => {
    const loadClientAndSync = async () => {
      if (selectedProcess) {
        const client = await getClienteData(selectedProcess.cliente_id);
        setSelectedClient(client);

        // Auto-reparo de dados de segurança para consulta pública (Sync silencioso)
        if (client && (!selectedProcess.cliente_cpf_cnpj || !selectedProcess.data_nascimento || !selectedProcess.cliente_nome)) {
          console.log("Detectados campos de segurança ausentes no processo, sincronizando...");
          try {
            const { db } = await import('../../firebase');
            const { updateDoc, doc: fsDoc } = await import('firebase/firestore');
            
            const updates: any = {};
            // Sincroniza CPF/CNPJ
            const documento = client.documento || (client as any).cpf;
            if (!selectedProcess.cliente_cpf_cnpj && documento) {
              updates.cliente_cpf_cnpj = documento.replace(/\D/g, '');
            }
            // Sincroniza Data de Nascimento
            if (!selectedProcess.data_nascimento && client.data_nascimento) {
              updates.data_nascimento = client.data_nascimento;
            }
            // Sincroniza Nome
            if (!selectedProcess.cliente_nome && client.nome) {
              updates.cliente_nome = client.nome;
            }

            if (Object.keys(updates).length > 0) {
              await updateDoc(fsDoc(db, 'order_processes', selectedProcess.id!), updates);
              // Atualiza o estado local para refletir a mudança
              setSelectedProcess(prev => prev?.id === selectedProcess.id ? { ...prev, ...updates } : prev);
            }
          } catch (e) {
            console.warn("Falha no auto-reparo do processo:", e);
          }
        }
      } else {
        setSelectedClient(null);
      }
    };
    loadClientAndSync();
  }, [selectedProcess]);

  const handleDownloadPDF = async (processo: OrderProcess) => {
    if (!isAdm && profile?.nivel !== 'GESTOR' && profile?.nivel !== 'VENDEDOR') {
      Swal.fire('Acesso Restrito', 'Você não tem permissão para esta ação.', 'error');
      return;
    }
    setGeneratingPdf(true);
    try {
      let cliente = await getClienteData(processo.cliente_id);
      
      if (!cliente) {
        console.warn("Dados do cliente não encontrados na base, usando dados do processo como fallback.");
        // Fallback para dados do processo se o cliente não for encontrado em nenhuma coleção
        cliente = {
          id: processo.cliente_id,
          nome: processo.cliente_nome || 'Não informado',
          documento: processo.cliente_cpf_cnpj || 'Não informado',
          data_nascimento: processo.data_nascimento || '',
          telefone: 'Não informado',
          especialista_id: processo.vendedor_id,
          data_entrada: processo.data_venda
        } as any;
      }
      
      const modelo = processo.modelo_id ? await obterModeloProcesso(processo.modelo_id) : null;
      
      gerarDocumentoProcesso(processo, cliente, modelo);
      
      Swal.fire({
        icon: 'success',
        title: 'PDF Gerado',
        text: 'A ficha técnica foi gerada e o download deve iniciar em instantes.',
        timer: 2000,
        showConfirmButton: false
      });
    } catch (error: any) {
      console.error("Erro ao gerar PDF:", error);
      Swal.fire('Erro', error.message || 'Falha ao gerar documento.', 'error');
    } finally {
      setGeneratingPdf(false);
    }
  };

  const handleDeleteProcess = async (processo: OrderProcess) => {
    if (!isAdm) {
      Swal.fire('Acesso Restrito', 'Apenas administradores podem excluir processos.', 'error');
      return;
    }
    const result = await Swal.fire({
      title: 'Excluir Processo?',
      text: `Tem certeza que deseja excluir o processo #${processo.protocolo} de ${processo.cliente_nome}? Esta ação removerá permanentemente o processo, histórico e pendências.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Sim, excluir permanentemente!',
      cancelButtonText: 'Cancelar'
    });

    if (result.isConfirmed) {
      setLoading(true);
      try {
        await excluirProcesso(processo.id!);
        Swal.fire('Excluído!', 'O processo foi removido com sucesso.', 'success');
        setSelectedProcess(null);
        
        // Refresh list
        const data = await listarTodosProcessos(profile || undefined);
        setProcessos(data);
      } catch (error) {
        console.error("Erro ao excluir processo:", error);
        Swal.fire('Erro', 'Falha ao excluir o processo.', 'error');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleUpdateStatus = async (processo: OrderProcess, novoStatus: OrderProcess['status_atual']) => {
    if (!isAdm) return;
    const oldStatus = processo.status_atual;
    
    if (novoStatus === 'Concluído') {
      const { value: fileUrl } = await Swal.fire({
        title: 'Finalizar Processo',
        text: 'Anexe o arquivo do diagnóstico (PDF ou Imagem). Isso liberará o resultado no Portal do Cliente.',
        input: 'file',
        inputAttributes: {
          'accept': 'application/pdf,image/*',
          'aria-label': 'Upload do diagnóstico'
        },
        showCancelButton: true,
        confirmButtonText: 'Enviar e Concluir',
        confirmButtonColor: '#10b981',
        cancelButtonText: 'Voltar',
        showLoaderOnConfirm: true,
        preConfirm: async (file) => {
          if (!file) {
            Swal.showValidationMessage('Você precisa selecionar um arquivo!');
            return false;
          }
          try {
            const { uploadFile } = await import('../../services/uploadService');
            const path = `diagnosticos/${processo.protocolo.replace('#', '')}_${Date.now()}_${file.name}`;
            const url = await uploadFile(file, path);
            return url;
          } catch (error: any) {
            Swal.showValidationMessage(`Erro no upload: ${error.message}`);
          }
        },
        allowOutsideClick: () => !Swal.isLoading()
      });

      if (fileUrl) {
        try {
          await atualizarStatusProcesso(
            processo.id!,
            novoStatus,
            auth.currentUser!.uid,
            oldStatus,
            fileUrl,
            'Processo concluído com sucesso pelo analista.'
          );

          // Notificar Interessados
          const { sendNotification } = await import('../../services/notificationService');
          const notifyUsers = [processo.cliente_id, processo.vendedor_id];
          for (const uid of notifyUsers) {
            if (uid) {
              await sendNotification({
                usuario_id: uid,
                titulo: '🚀 PROCESSO CONCLUÍDO!',
                mensagem: `Seu processo de ${processo.servico_nome} foi finalizado com sucesso.`,
                tipo: 'PROCESS'
              });
            }
          }

          Swal.fire({
            title: 'PROCESSO ENTREGUE!',
            html: `<div class="text-left text-xs space-y-2">
                    <p>✅ <b>Portal do Cliente:</b> Mensagem de parabéns e garantia ativadas.</p>
                    <p>🔔 <b>Notificação Som:</b> Enviada para o Vendedor.</p>
                    <p>💰 <b>Comissão:</b> Liberada para o Gestor.</p>
                   </div>`,
            icon: 'success'
          });
          // Refresh
          const procs = await listarTodosProcessos(profile || undefined);
          setProcessos(procs);
        } catch (error: any) {
          Swal.fire('Erro', error.message || 'Falha ao concluir processo.', 'error');
        }
      }
    } else {
      const { isConfirmed } = await Swal.fire({
        title: 'Confirmar Mudança?',
        text: `O cliente, o vendedor e o gestor serão notificados sobre o status: ${novoStatus}`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sim, Atualizar',
        confirmButtonColor: '#2563eb'
      });

      if (isConfirmed) {
        try {
          await atualizarStatusProcesso(
            processo.id!,
            novoStatus,
            auth.currentUser!.uid,
            oldStatus,
            undefined,
            `Status alterado para ${novoStatus}`
          );

          // Notificar Interessados
          const { sendNotification } = await import('../../services/notificationService');
          const notifyUsers = [processo.cliente_id, processo.vendedor_id];
          for (const uid of notifyUsers) {
            if (uid) {
              await sendNotification({
                usuario_id: uid,
                titulo: '🚀 AVANÇO NO PROCESSO',
                mensagem: `Seu processo de ${processo.servico_nome} avançou para: ${novoStatus}.`,
                tipo: 'PROCESS'
              });
            }
          }

          Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'success',
            title: 'Status Atualizado e Equipe Notificada!',
            showConfirmButton: false,
            timer: 2500
          });
          // Refresh
          const procs = await listarTodosProcessos(profile || undefined);
          setProcessos(procs);
        } catch (error: any) {
          Swal.fire('Erro', error.message || 'Falha ao atualizar status.', 'error');
        }
      }
    }
  };

  const handleAbrirPendencia = async (processo: OrderProcess) => {
    if (!isAdm) {
      Swal.fire('Acesso Restrito', 'Apenas analistas podem reprovar documentos ou abrir pendências.', 'error');
      return;
    }
    const { value: descricao } = await Swal.fire({
      title: 'Informar Pendência',
      input: 'textarea',
      inputPlaceholder: 'Descreva o problema (Ex: Documento borrado, CPF inválido no site da RF)...',
      showCancelButton: true,
      confirmButtonText: 'Notificar Vendedor e Gestor',
      confirmButtonColor: '#f59e0b'
    });

    if (descricao) {
      try {
        await abrirPendenciaCascata({
          vendaId: processo.venda_id,
          processo_id: processo.id,
          descricao,
          criado_por_id: auth.currentUser!.uid
        });

        // Notificar Cliente e Equipe
        const { notificarPendenciaManual } = await import('../../services/notificationService');
        await notificarPendenciaManual(processo, processo.cliente_id, descricao);

        Swal.fire('Pendência Aberta', 'O cliente e o vendedor responsável já receberam o alerta.', 'warning');
      } catch (error: any) {
        Swal.fire('Erro', error.message || 'Falha ao abrir pendência.', 'error');
      }
    }
  };

  const handleNotificarPendencias = async (processo: OrderProcess) => {
    const totalCampos = processo.dados_faltantes?.length || 0;
    const totalDocs = processo.pendencias_iniciais?.length || 0;
    const envDocs = processo.documentos_enviados?.length || 0;
    const faltamDocs = totalDocs - envDocs;

    if (totalCampos === 0 && faltamDocs <= 0) {
      Swal.fire('Tudo em Ordem', 'Não há pendências de ficha técnica para este processo.', 'info');
      return;
    }

    try {
      const { notificarPendenciaFicha } = await import('../../services/notificationService');
      await notificarPendenciaFicha(processo, processo.cliente_id, totalCampos, Math.max(0, faltamDocs));

      Swal.fire({
        icon: 'success',
        title: 'Cliente Cobrado!',
        text: 'Uma notificação de pendência foi enviada para o portal do cliente e para a equipe responsável.',
        timer: 3000,
        showConfirmButton: false
      });
    } catch (error: any) {
      Swal.fire('Erro', error.message || 'Falha ao enviar notificação.', 'error');
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const procs = await listarTodosProcessos(profile || undefined);
        setProcessos(procs);
      } catch (error) {
        console.error("Erro ao carregar dados operacionais:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const getProcessProgress = (processo: OrderProcess) => {
    const reqDocs = processo.pendencias_iniciais || [];
    if (reqDocs.length === 0) return 100;
    const envDocs = processo.documentos_enviados || [];
    const count = reqDocs.filter(d => envDocs.includes(d)).length;
    return Math.round((count / reqDocs.length) * 100);
  };

  const isProcessReady = (processo: OrderProcess) => {
    const reqDocs = processo.pendencias_iniciais || [];
    const reqFields = processo.dados_faltantes || [];
    
    // Dados críticos para rastreio público
    const hasTrackingData = !!processo.cliente_cpf_cnpj && !!processo.data_nascimento;

    const docsReady = reqDocs.length === 0 || (processo.documentos_enviados || []).length >= reqDocs.length;
    const fieldsReady = reqFields.length === 0;
    
    return docsReady && fieldsReady && hasTrackingData;
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const filteredProcessos = processos.filter(p => {
    const matchesSearch = 
      (p.cliente_nome || '').toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
      (p.protocolo || '').toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
      (p.servico_nome || '').toLowerCase().includes(debouncedSearchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || p.status_atual === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const stats = {
    totalFila: processos.filter(p => p.status_atual !== 'Concluído').length,
    totalAtraso: processos.filter(p => {
      if (p.status_atual === 'Concluído') return false;
      const dataVenda = p.data_venda?.toDate() || new Date();
      const diffTime = Math.abs(new Date().getTime() - dataVenda.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > (p.prazo_estimado_dias || 7);
    }).length,
    totalConcluidoHoje: processos.filter(p => {
      if (p.status_atual !== 'Concluído') return false;
      const dataConclusao = p.data_conclusao_real?.toDate() || new Date();
      const today = new Date();
      return dataConclusao.getDate() === today.getDate() &&
             dataConclusao.getMonth() === today.getMonth() &&
             dataConclusao.getFullYear() === today.getFullYear();
    }).length
  };

  const [displayFila, setDisplayFila] = useState(0);
  const [displayAtraso, setDisplayAtraso] = useState(0);
  const [displayConcluido, setDisplayConcluido] = useState(0);

  useEffect(() => {
    if (!loading) {
      if (stats.totalFila > 0) {
        let start = 0; const end = stats.totalFila; const duration = 1000;
        const inc = end / (duration / 16);
        const timer = setInterval(() => { start += inc; if (start >= end) { setDisplayFila(end); clearInterval(timer); } else { setDisplayFila(Math.floor(start)); } }, 16);
      }
      if (stats.totalAtraso > 0) {
        let start = 0; const end = stats.totalAtraso; const duration = 1000;
        const inc = end / (duration / 16);
        const timer = setInterval(() => { start += inc; if (start >= end) { setDisplayAtraso(end); clearInterval(timer); } else { setDisplayAtraso(Math.floor(start)); } }, 16);
      }
      if (stats.totalConcluidoHoje > 0) {
        let start = 0; const end = stats.totalConcluidoHoje; const duration = 1000;
        const inc = end / (duration / 16);
        const timer = setInterval(() => { start += inc; if (start >= end) { setDisplayConcluido(end); clearInterval(timer); } else { setDisplayConcluido(Math.floor(start)); } }, 16);
      }
    }
  }, [loading, stats]);

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center gap-4">
          <Activity className="text-blue-600 animate-spin" size={40} />
          <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Carregando Operação...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10 pb-20">
      {/* HEADER OPERACIONAL (Layout 4.0 Glow) */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 bg-gradient-to-br from-[#020617] to-[#0a0a2e] p-6 md:p-12 rounded-[2rem] md:rounded-[3rem] border border-slate-800 shadow-[0_20px_50px_rgba(0,0,0,0.5)] relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none group-hover:rotate-12 transition-transform duration-1000">
          <Activity size={240} className="text-blue-500" />
        </div>
        
        {/* Animated Glow Elements */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-blue-600/10 blur-[120px] rounded-full pointer-events-none transform translate-x-1/3 -translate-y-1/3 group-hover:bg-blue-600/20 transition-all duration-1000"></div>
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-emerald-600/5 blur-[80px] rounded-full pointer-events-none transform -translate-x-1/3 translate-y-1/3"></div>

        <div className="space-y-4 relative z-10 w-full lg:w-auto">
          <div className="flex items-center gap-6">
            <div className="size-16 bg-blue-500/10 border border-blue-500/20 rounded-[1.5rem] flex items-center justify-center shadow-[0_0_20px_rgba(59,130,246,0.2)]">
               <Activity className="text-blue-400" size={28} />
            </div>
            <div>
              <h1 className="text-3xl md:text-5xl font-black text-white uppercase tracking-tighter italic leading-none">
                { (profile?.nivel === 'GESTOR' || profile?.nivel === 'VENDEDOR') ? 'Meus Processos' : 'Fila de Produção' }
              </h1>
              <p className="text-blue-400 text-[10px] font-black uppercase tracking-[0.2em] mt-2">GSA IA Operational Engine</p>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-[#0F172A] w-fit px-4 py-2 rounded-xl border border-slate-800">
            <div className="size-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_10px_rgba(52,211,153,0.8)]"></div>
            <p className="text-slate-400 text-xs font-black uppercase tracking-widest">
              Terminal: <span className="text-white">{auth.currentUser?.displayName || 'Analista GSA'}</span>
            </p>
          </div>
        </div>
        
        {/* MINI DASHBOARD VIP ANALISTA */}
        <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-4 relative z-10 w-full lg:w-auto mt-4 lg:mt-0">
          <div className="bg-[#0B0F19] px-6 md:px-10 py-5 rounded-[1.8rem] border border-slate-800/50 shadow-inner flex flex-col items-center justify-center relative overflow-hidden group/card shadow-[0_0_20px_rgba(0,0,0,0.5)]">
             <div className="absolute inset-0 bg-gradient-to-t from-blue-900/10 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity"></div>
             <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">Em Fila</p>
             <p className="text-3xl md:text-4xl font-black text-blue-400 italic tracking-tighter drop-shadow-[0_0_10px_rgba(59,130,246,0.3)]">{displayFila.toString().padStart(2, '0')}</p>
          </div>
          <div className="bg-[#0B0F19] px-6 md:px-10 py-5 rounded-[1.8rem] border border-rose-900/20 shadow-inner flex flex-col items-center justify-center relative overflow-hidden group/card shadow-[0_0_20px_rgba(0,0,0,0.5)]">
             <div className="absolute inset-0 bg-gradient-to-t from-rose-900/10 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity"></div>
            <p className="text-[9px] font-black text-rose-500/70 uppercase tracking-[0.2em] mb-1">Atraso SLA</p>
            <p className="text-3xl md:text-4xl font-black text-rose-500 italic tracking-tighter drop-shadow-[0_0_10px_rgba(225,29,72,0.3)]">{displayAtraso.toString().padStart(2, '0')}</p>
          </div>
          <div className="col-span-2 sm:col-span-1 bg-[#0B0F19] px-6 md:px-10 py-5 rounded-[1.8rem] border border-emerald-900/20 shadow-inner flex flex-col items-center justify-center relative overflow-hidden group/card shadow-[0_0_20px_rgba(0,0,0,0.5)]">
             <div className="absolute inset-0 bg-gradient-to-t from-emerald-900/10 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity"></div>
            <p className="text-[9px] font-black text-emerald-500/70 uppercase tracking-[0.2em] mb-1">Concluídos</p>
            <p className="text-3xl md:text-4xl font-black text-emerald-500 italic tracking-tighter drop-shadow-[0_0_10px_rgba(52,211,153,0.3)]">{displayConcluido.toString().padStart(2, '0')}</p>
          </div>
        </div>
      </div>

      {/* FILTROS E BUSCA RÁPIDA */}
      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="w-full md:flex-1 relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
          <input 
            type="text" 
            placeholder="Buscar Protocolo ou Cliente..." 
            className="w-full pl-14 pr-6 py-4 md:py-5 bg-white border border-slate-100 rounded-[1.5rem] md:rounded-[1.8rem] text-[10px] md:text-[11px] font-black uppercase tracking-widest text-[#0a0a2e] placeholder:text-slate-300 focus:ring-4 focus:ring-blue-500/10 outline-none shadow-sm transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <select 
          className="w-full md:w-auto bg-white border border-slate-100 rounded-[1.5rem] md:rounded-[1.8rem] px-8 py-4 md:py-5 text-[10px] font-black uppercase tracking-[0.2em] outline-none shadow-sm text-slate-500 cursor-pointer hover:text-[#0a0a2e] transition-all"
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        >
          <option value="all">Status: Todos</option>
          <option value="Pendente">Pendente</option>
          <option value="Em Análise">Em Análise</option>
          <option value="Protocolado">Protocolado</option>
          <option value="Em Andamento">Em Andamento</option>
          <option value="Concluído">Concluído</option>
          <option value="Aguardando Documentação">Aguardando Documentação</option>
        </select>
      </div>

      {/* LISTAGEM DE PROCESSOS (Fila Real) */}
      <div className="grid grid-cols-1 gap-6">
        {filteredProcessos.map((processo, idx) => {
          const dataVenda = processo.data_venda?.toDate() || new Date();
          const diffTime = Math.abs(new Date().getTime() - dataVenda.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          const isAtrasado = diffDays > (processo.prazo_estimado_dias || 7);
          const ready = isProcessReady(processo);

          return (
            <motion.div 
              key={processo.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05, duration: 0.5 }}
              className={`bg-white rounded-2xl md:rounded-[2.5rem] border p-4 sm:p-6 md:p-8 shadow-sm flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 sm:gap-6 md:gap-8 transition-all hover:shadow-2xl hover:-translate-y-1 group ${
                isAtrasado ? 'border-rose-100 bg-rose-50/10' : 'border-slate-100'
              }`}
            >
              {/* Info Cliente e Protocolo */}
              <div className="space-y-2 sm:space-y-3 min-w-[200px] w-full xl:w-auto">
                <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                  <div className="bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100">
                    <span className="text-[7px] sm:text-[9px] font-black text-blue-600 uppercase tracking-widest">
                      #{processo.protocolo || processo.id?.slice(-6).toUpperCase()}
                    </span>
                  </div>
                  {isAtrasado && (
                    <div className="bg-rose-500 px-2.5 py-1 rounded-full shadow-lg shadow-rose-500/20 animate-pulse">
                      <span className="text-[7px] sm:text-[8px] font-black text-white uppercase tracking-widest">SLA Crítico</span>
                    </div>
                  )}
                  {ready ? (
                    <div className="bg-emerald-500 px-2.5 py-1 rounded-full shadow-lg shadow-emerald-500/20">
                      <span className="text-[7px] sm:text-[8px] font-black text-white uppercase tracking-widest">Docs OK</span>
                    </div>
                  ) : (
                    <div className="bg-amber-500 px-2.5 py-1 rounded-full shadow-lg shadow-amber-500/20">
                      <span className="text-[7px] sm:text-[8px] font-black text-white uppercase tracking-widest">Pendente</span>
                    </div>
                  )}
                </div>
                <h3 className="text-lg sm:text-xl md:text-2xl font-black text-[#0a0a2e] uppercase italic leading-none group-hover:text-blue-600 transition-colors truncate max-w-full">{processo.cliente_nome}</h3>
                
                {/* Alerta de Dados Faltantes Detalhado */}
                {!ready && (
                  <div className="flex flex-wrap gap-1 md:gap-2 mt-1">
                    {!processo.cliente_cpf_cnpj && (
                      <span className="text-[6px] sm:text-[7px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100 uppercase tracking-tighter">Falta CPF</span>
                    )}
                    {!processo.data_nascimento && (
                      <span className="text-[6px] sm:text-[7px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100 uppercase tracking-tighter">Falta Nascimento</span>
                    )}
                    {processo.dados_faltantes?.slice(0, 3).map(f => (
                      <span key={f} className="text-[6px] sm:text-[7px] font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100 uppercase tracking-tighter truncate max-w-[80px]">Falta {f}</span>
                    ))}
                    {processo.dados_faltantes && processo.dados_faltantes.length > 3 && (
                      <span className="text-[6px] sm:text-[7px] font-bold text-blue-400 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-50">+{processo.dados_faltantes.length - 3}</span>
                    )}
                  </div>
                )}

                <div className="flex items-center gap-2 text-slate-400 overflow-hidden">
                  <div className="size-1 bg-slate-300 rounded-full shrink-0" />
                  <p className="text-[8px] sm:text-[10px] font-black uppercase tracking-widest truncate">{processo.servico_nome}</p>
                </div>
              </div>

              {/* Timeline de Status (Dropdown Master / View Only for Sales) */}
              <div className="flex-1 w-full xl:w-auto space-y-2">
                <p className="text-[7px] sm:text-[8px] md:text-[9px] font-black text-slate-300 uppercase tracking-[0.3em] ml-1">Fluxo Operacional</p>
                {isAdm ? (
                  <div className="relative group/select">
                    <select 
                      value={processo.status_atual}
                      onChange={(e) => handleUpdateStatus(processo, e.target.value as any)}
                      className="w-full xl:w-72 bg-slate-50 border border-slate-100 rounded-xl sm:rounded-2xl text-[9px] sm:text-[11px] font-black uppercase tracking-widest text-[#0a0a2e] py-3.5 sm:py-4 pl-4 sm:pl-6 pr-10 focus:ring-4 focus:ring-blue-500/10 cursor-pointer appearance-none transition-all hover:bg-blue-50"
                    >
                      <option value="Pendente">1. Pendente</option>
                      <option value="Em Análise">2. Em Análise</option>
                      <option value="Protocolado">3. Protocolado</option>
                      <option value="Em Andamento">4. Em Andamento</option>
                      <option value="Aguardando Documentação">5. Aguardando Doc.</option>
                      <option value="Concluído">6. CONCLUIR PROCESSO</option>
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-blue-400 group-hover/select:translate-y-[-40%] transition-transform">
                      <ChevronRight size={16} className="rotate-90" />
                    </div>
                  </div>
                ) : (
                  <div className="w-full xl:w-72 bg-[#020617] border border-slate-800 rounded-xl sm:rounded-2xl py-3.5 sm:py-4 px-6 flex items-center justify-between">
                     <span className="text-[9px] sm:text-[11px] font-black uppercase tracking-widest text-blue-400 italic">
                        {processo.status_atual}
                     </span>
                     <div className="size-1.5 rounded-full bg-blue-500 animate-pulse shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>
                  </div>
                )}
              </div>

              {/* Time & Team (Visible only on larger screens) */}
              <div className="hidden xl:flex items-center gap-12 border-x border-slate-50 px-12">
                <div className="text-center space-y-1">
                  <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Data Início</p>
                  <div className="flex items-center gap-2 text-[#0a0a2e]">
                    <Calendar size={14} className="text-blue-500" />
                    <p className="text-xs font-black uppercase italic">
                      {processo.data_venda?.toDate ? format(processo.data_venda.toDate(), "dd/MM/yy") : 'N/A'}
                    </p>
                  </div>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Responsável</p>
                  <div className="flex items-center gap-2 text-[#0a0a2e]">
                    <User size={14} className="text-blue-500" />
                    <p className="text-[10px] font-black uppercase tracking-tight truncate max-w-[120px]">
                      {processo.vendedor_nome || 'N/A'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Botões de Ação */}
              <div className="grid grid-cols-2 xl:flex gap-2 sm:gap-3 w-full xl:w-auto">
                <button 
                  onClick={() => setSelectedProcess(processo)}
                  className="bg-slate-50 text-slate-400 hover:bg-[#0a0a2e] hover:text-white h-12 sm:h-14 xl:w-14 rounded-xl sm:rounded-2xl transition-all shadow-sm flex items-center justify-center border border-slate-100 group/btn" 
                  title="Ver Pasta do Cliente"
                >
                  <FolderOpen size={20} className="group-hover/btn:scale-110 transition-transform" />
                  <span className="ml-2 xl:hidden text-[10px] font-black uppercase tracking-widest">Abrir Pasta</span>
                </button>
                {isAdm && (
                  <button 
                    onClick={() => handleAbrirPendencia(processo)}
                    className="bg-rose-50 text-rose-500 hover:bg-rose-600 hover:text-white h-12 sm:h-14 xl:w-14 rounded-xl sm:rounded-2xl transition-all shadow-sm flex items-center justify-center border border-rose-100 group/btn" 
                    title="Abrir Pendência"
                  >
                    <AlertTriangle size={20} className="group-hover/btn:scale-110 transition-transform" />
                    <span className="ml-2 xl:hidden text-[10px] font-black uppercase tracking-widest">Pendência</span>
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}

        {filteredProcessos.length === 0 && (
          <div className="py-32 text-center bg-white rounded-[3.5rem] border-2 border-dashed border-slate-100 shadow-inner">
            <div className="size-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
              <AlertCircle size={40} className="text-slate-200" />
            </div>
            <h3 className="text-2xl font-black text-slate-300 uppercase tracking-tighter italic">Nenhum processo na fila de produção</h3>
            <p className="text-slate-400 text-sm mt-2 font-medium">Aguarde novas vendas concluídas para iniciar a operação.</p>
          </div>
        )}
      </div>

      {/* Modal de Auditoria Detalhada (Layout 4.0) */}
      <AnimatePresence>
        {selectedProcess && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-5xl max-h-[95vh] md:max-h-[90vh] rounded-[2rem] md:rounded-[3.5rem] overflow-hidden shadow-2xl flex flex-col relative border border-slate-100"
            >
              <button 
                onClick={() => setSelectedProcess(null)}
                className="absolute top-4 right-4 md:top-8 md:right-8 z-50 size-10 md:size-12 bg-white hover:bg-slate-50 rounded-full flex items-center justify-center text-slate-400 shadow-xl border border-slate-100 transition-all"
              >
                <X size={20} className="md:size-6" />
              </button>

              <div className="p-6 md:p-10 border-b border-slate-50 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-4 md:gap-6">
                  <div className="size-12 md:size-16 bg-blue-600 rounded-2xl md:rounded-[1.5rem] flex items-center justify-center text-white shadow-2xl shadow-blue-500/20 shrink-0">
                    <ShieldCheck className="size-6 md:size-8" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-lg md:text-3xl font-black text-[#0a0a2e] uppercase tracking-tighter italic truncate">Auditoria</h3>
                    <p className="text-[8px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest truncate">Doc: #{selectedProcess.protocolo || selectedProcess.id?.slice(-6).toUpperCase()}</p>
                  </div>
                </div>

                {/* Botão de Excluir para ADM_MASTER */}
                {isAdm && (
                  <button 
                    onClick={() => handleDeleteProcess(selectedProcess)}
                    className="mr-16 px-6 py-3 bg-red-50 text-red-600 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-red-600 hover:text-white transition-all flex items-center gap-2 shadow-sm"
                  >
                    <Trash2 size={14} />
                    Excluir Processo
                  </button>
                )}
              </div>

              <div className="flex-1 overflow-y-auto p-5 md:p-10 space-y-6 md:space-y-10 custom-scrollbar">
                {/* Cabeçalho do Cliente */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8">
                  <div className="md:col-span-8 bg-slate-50 p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] border border-slate-100 shadow-inner">
                    <div className="flex items-center gap-3 mb-4 md:mb-6">
                      <div className="size-8 bg-white rounded-xl flex items-center justify-center shadow-sm">
                        <UserCheck className="text-blue-600" size={16} />
                      </div>
                      <span className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">Cliente</span>
                    </div>
                    <h4 className="text-xl md:text-3xl font-black text-[#0a0a2e] uppercase italic mb-3 md:mb-4 truncate flex items-center gap-3">
                      {selectedProcess.cliente_nome}
                      {isAdm && (
                        <button 
                          onClick={async () => {
                            const { value: novoNome } = await Swal.fire({
                              title: 'Editar Nome do Cliente',
                              input: 'text',
                              inputValue: selectedProcess.cliente_nome,
                              showCancelButton: true
                            });
                            if (novoNome && novoNome !== selectedProcess.cliente_nome) {
                              const { updateCliente } = await import('../../services/leadService');
                              const { registrarLogAuditoria } = await import('../../services/orderService');
                              const { db } = await import('../../firebase');
                              const { updateDoc, doc: fsDoc } = await import('firebase/firestore');
                              
                              await updateCliente(selectedProcess.cliente_id, { nome: novoNome });
                              await updateDoc(fsDoc(db, 'order_processes', selectedProcess.id!), { cliente_nome: novoNome });
                              await registrarLogAuditoria(selectedProcess.id!, `Nome do cliente alterado para: ${novoNome}`, profile?.uid || '', profile?.nome_completo || 'Analista');
                              setSelectedProcess({...selectedProcess, cliente_nome: novoNome});
                              Swal.fire('Atualizado', 'Nome alterado com sucesso.', 'success');
                            }
                          }}
                          className="p-1 hover:bg-white rounded-lg text-slate-300 hover:text-blue-600 transition-all"
                        >
                          <Edit3 size={16} />
                        </button>
                      )}
                    </h4>
                    <div className="flex flex-wrap gap-4 md:gap-6">
                      <div className="space-y-1">
                        <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest">Documento</p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs md:text-sm font-black text-slate-600 uppercase tracking-tight">{selectedProcess.cliente_cpf_cnpj || 'N/A'}</p>
                          {isAdm && (
                            <button 
                              onClick={async () => {
                                const { value: novoDoc } = await Swal.fire({
                                  title: 'Editar CPF/CNPJ',
                                  input: 'text',
                                  inputValue: selectedProcess.cliente_cpf_cnpj,
                                  showCancelButton: true
                                });
                                if (novoDoc !== undefined) {
                                  const cleanDoc = novoDoc.replace(/\D/g, '');
                                  const { updateCliente } = await import('../../services/leadService');
                                  const { registrarLogAuditoria } = await import('../../services/orderService');
                                  const { db } = await import('../../firebase');
                                  const { updateDoc, doc: fsDoc } = await import('firebase/firestore');
                                  
                                  await updateCliente(selectedProcess.cliente_id, { documento: cleanDoc });
                                  await updateDoc(fsDoc(db, 'order_processes', selectedProcess.id!), { cliente_cpf_cnpj: cleanDoc });
                                  await registrarLogAuditoria(selectedProcess.id!, `CPF/CNPJ do cliente alterado para: ${cleanDoc}`, profile?.uid || '', profile?.nome_completo || 'Analista');
                                  setSelectedProcess({...selectedProcess, cliente_cpf_cnpj: cleanDoc});
                                  Swal.fire('Atualizado', 'Documento alterado com sucesso.', 'success');
                                }
                              }}
                              className="p-1 hover:bg-white rounded-lg text-slate-300 hover:text-blue-600 transition-all"
                            >
                              <Edit3 size={12} />
                            </button>
                          )}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest">Nascimento</p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs md:text-sm font-black text-slate-600 uppercase tracking-tight">{selectedProcess.data_nascimento || 'N/A'}</p>
                          {isAdm && (
                            <button 
                              onClick={async () => {
                                const { value: novaData } = await Swal.fire({
                                  title: 'Editar Data de Nascimento',
                                  input: 'text',
                                  inputPlaceholder: 'DD/MM/AAAA',
                                  inputValue: selectedProcess.data_nascimento,
                                  showCancelButton: true
                                });
                                if (novaData !== undefined) {
                                  const { updateCliente } = await import('../../services/leadService');
                                  const { registrarLogAuditoria } = await import('../../services/orderService');
                                  const { db } = await import('../../firebase');
                                  const { updateDoc, doc: fsDoc } = await import('firebase/firestore');
                                  
                                  await updateCliente(selectedProcess.cliente_id, { data_nascimento: novaData });
                                  await updateDoc(fsDoc(db, 'order_processes', selectedProcess.id!), { data_nascimento: novaData });
                                  await registrarLogAuditoria(selectedProcess.id!, `Data de nascimento alterada para: ${novaData}`, profile?.uid || '', profile?.nome_completo || 'Analista');
                                  setSelectedProcess({...selectedProcess, data_nascimento: novaData});
                                  Swal.fire('Atualizado', 'Data alterada com sucesso.', 'success');
                                }
                              }}
                              className="p-1 hover:bg-white rounded-lg text-slate-300 hover:text-blue-600 transition-all"
                            >
                              <Edit3 size={12} />
                            </button>
                          )}
                        </div>
                      </div>
                      {isAdm && (
                        <div className="space-y-1">
                          <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest">WhatsApp</p>
                          <div className="flex items-center gap-2">
                            <p className="text-xs md:text-sm font-black text-slate-600 uppercase tracking-tight">{selectedClient?.whatsapp || selectedClient?.telefone || 'N/A'}</p>
                            <button 
                              onClick={async () => {
                                const { value: novoTel } = await Swal.fire({
                                  title: 'Editar WhatsApp do Cliente',
                                  input: 'text',
                                  inputValue: selectedClient?.whatsapp || selectedClient?.telefone,
                                  showCancelButton: true
                                });
                                if (novoTel !== undefined) {
                                  const cleanTel = novoTel.replace(/\D/g, '');
                                  const { updateCliente } = await import('../../services/leadService');
                                  await updateCliente(selectedProcess.cliente_id, { whatsapp: cleanTel, telefone: cleanTel });
                                  setSelectedClient({...selectedClient, whatsapp: cleanTel, telefone: cleanTel});
                                  Swal.fire('Atualizado', 'WhatsApp alterado com sucesso.', 'success');
                                }
                              }}
                              className="p-1 hover:bg-white rounded-lg text-slate-300 hover:text-blue-600 transition-all"
                            >
                              <Edit3 size={12} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="md:col-span-4 bg-[#0a0a2e] p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] text-white flex flex-col justify-center shadow-2xl shadow-blue-900/30">
                    <span className="text-[9px] font-black text-blue-300 uppercase tracking-widest mb-1 md:mb-2">Status</span>
                    <h4 className="text-xl md:text-2xl font-black uppercase italic leading-none text-blue-400">{selectedProcess.status_atual}</h4>
                  </div>
                </div>

                {/* Grid Duplo para Mobile e Desktop */}
                <div className="flex flex-col xl:flex-row gap-6 md:gap-10 h-auto xl:h-[600px]">
                  {/* Checklist de Documentação */}
                  <div className="flex-1 space-y-4 md:space-y-6">
                    <div className="flex items-center justify-between px-2">
                      <div className="flex items-center gap-3">
                        <div className="size-8 md:size-10 bg-slate-50 rounded-xl flex items-center justify-center shadow-sm">
                          <FileText size={18} className="text-blue-600" />
                        </div>
                        <h4 className="text-sm md:text-lg font-black text-[#0a0a2e] uppercase tracking-tighter italic whitespace-nowrap">Documentos</h4>
                      </div>
                      <div className="bg-blue-50 px-3 md:px-4 py-1.5 rounded-full border border-blue-100 shrink-0">
                        <span className="text-[8px] md:text-[10px] font-black text-blue-600 uppercase tracking-widest">
                          {selectedProcess.documentos_enviados?.length || 0}/{selectedProcess.pendencias_iniciais?.length || 0} OK
                        </span>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 gap-3 md:gap-4 overflow-y-visible xl:overflow-y-auto pr-0 xl:pr-4 custom-scrollbar">
                      {selectedProcess.pendencias_iniciais?.map((docKey) => {
                        const isEnviado = selectedProcess.documentos_enviados?.includes(docKey);
                        return (
                          <div 
                            key={docKey}
                            className={`flex items-center justify-between p-4 md:p-6 rounded-2xl md:rounded-[1.8rem] border transition-all ${
                              isEnviado 
                                ? 'bg-emerald-50 border-emerald-100 shadow-sm' 
                                : 'bg-slate-50 border-slate-100'
                            }`}
                          >
                            <div className="flex items-center gap-3 md:gap-4 min-w-0">
                              <div className={`size-10 md:size-12 rounded-xl md:rounded-2xl flex items-center justify-center shadow-sm shrink-0 ${
                                isEnviado ? 'bg-white text-emerald-500' : 'bg-white text-slate-300'
                              }`}>
                                {isEnviado ? <CheckCircle className="size-5 md:size-6" /> : <Clock className="size-5 md:size-6" />}
                              </div>
                              <span className={`text-[10px] md:text-[11px] font-black uppercase tracking-tight truncate ${
                                isEnviado ? 'text-emerald-700' : 'text-slate-400'
                              }`}>
                                {requirementsConfig.document_labels[docKey] || docKey}
                              </span>
                            </div>
                          {isEnviado && (
                            <div className="flex gap-2">
                              <a 
                                href={selectedClient?.[docKey]} 
                                target="_blank" 
                                rel="noreferrer"
                                className="size-10 bg-white text-emerald-600 hover:bg-emerald-600 hover:text-white rounded-xl transition-all shadow-sm flex items-center justify-center border border-emerald-100"
                                title="Ver Arquivo"
                              >
                                <ExternalLink size={16} />
                              </a>
                              {isAdm && (
                                <button 
                                  onClick={() => handleAbrirPendencia(selectedProcess)}
                                  className="size-10 bg-white text-rose-600 hover:bg-rose-600 hover:text-white rounded-xl transition-all shadow-sm flex items-center justify-center border border-rose-100"
                                  title="Reprovar / Abrir Pendência"
                                >
                                  <XCircle size={16} />
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Dados da Ficha */}
                <div className="flex-1 overflow-y-visible xl:overflow-y-auto p-0 xl:p-8 custom-scrollbar">
                  <SmartFicha 
                    processos={[selectedProcess]} 
                    clienteDados={selectedClient || { 
                      id: selectedProcess.cliente_id, 
                      uid: selectedProcess.cliente_id,
                      nome_completo: selectedProcess.cliente_nome,
                      cpf: selectedProcess.cliente_cpf_cnpj,
                      data_nascimento: selectedProcess.data_nascimento,
                      ...selectedProcess
                    }} 
                    onUpdate={async () => {
                      setSelectedProcess(null);
                      const procs = await listarTodosProcessos(profile || undefined);
                      setProcessos(procs);
                    }} 
                  />
                </div>
              </div>
            </div>

            <div className="p-6 md:p-10 bg-slate-50/50 border-t border-slate-100 flex flex-wrap justify-center sm:justify-end gap-3 md:gap-4 shrink-0">
                <button 
                  onClick={() => setSelectedProcess(null)}
                  className="px-6 md:px-10 py-4 md:py-5 rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-[#0a0a2e] transition-all"
                >
                  Fechar
                </button>
                {!isProcessReady(selectedProcess) && isAdm && (
                  <button 
                    onClick={() => handleNotificarPendencias(selectedProcess)}
                    className="px-6 md:px-10 py-4 md:py-5 bg-amber-50 text-amber-600 border border-amber-100 rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-amber-100 shadow-sm transition-all flex items-center justify-center gap-2"
                  >
                    <AlertTriangle size={14} />
                    Cobrar
                  </button>
                )}
                <button 
                  onClick={() => handleDownloadPDF(selectedProcess)}
                  disabled={generatingPdf}
                  className="px-6 md:px-10 py-4 md:py-5 bg-white border border-slate-100 text-[#0a0a2e] rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 shadow-sm transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {generatingPdf ? <Loader2 className="animate-spin" size={14} /> : <FileDown size={14} />}
                  Ficha Técnica
                </button>
                {isAdm && (
                  <button className="px-6 md:px-10 py-4 md:py-5 bg-[#0a0a2e] text-white rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] hover:scale-105 active:scale-95 shadow-2xl shadow-blue-900/30 transition-all">
                    Protocolo Final
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
